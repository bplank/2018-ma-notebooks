__author__ = "bplank"
"""
Logistic regression classifier in DyNet (with n-hot feature encoding)

Q1: What does the read_data method return? (how are instances and labels represented?)
Q2: Prepare the features for the network (n-hot encoding)
Q3: Define the parameters of the model. Now you are ready to run the code!
Q4: Examine the calc_scores function, what does it do?
Q5: What performance do you get it your run it for 10 epochs? I've provided you with Sklearn code as well (on the given data split). Compare it to the Sklearn model. 
    Do you get different results? What could be a possible reason for this?

Q6: Which steps do you have to modify to get a multinomial logistic regression model? (for multi-class prediction?) hint: loss function, final layer 

"""
from collections import defaultdict
import time
import random
import dynet as dy
import numpy as np


# mapping functions
w2i = defaultdict(lambda: len(w2i))
t2i = defaultdict(lambda: len(t2i))
UNK = w2i["<unk>"]

def read_data(filename):
    """
    Return a list of tuples (words_in_sentence, label) - both converted to ids
    :param filename:
    :return:
    """
    for line in open(filename):
        line = line.strip()
        label, text = line.split(" ||| ")
        label = label.strip()
        word_ids = [w2i[word] for word in text.split()]
        label_enc = t2i[label]
        yield (word_ids, label_enc)


def convert_to_n_hot(X, vocab_size):
    """
    Convert instances to n-hot encoding
    :param X:
    :param vocab_size:
    :return:
    """
    out = []
    for word_ids, label in X:
        n_hot = np.zeros(vocab_size)
        for w_idx in word_ids:
            n_hot[w_idx] = 1   # Q1: What happens here?
        out.append((n_hot, label))
    return out


## prepare data
train = list(read_data("data/rt-sentiment.train"))

w2i = defaultdict(lambda: UNK, w2i) # nice trick to freeze vocab

dev = list(read_data("data/rt-sentiment.dev"))
test = list(read_data("data/rt-sentiment.test"))

## Q2: convert instances to n-hot representations
vocab_size = None

X_train = None
X_dev = None
X_test = None

## end Q2

print("vocab size: {}".format(vocab_size))

## printing out an example
print("11th instance (as word indices)", train[10])
print("11th instance (n-hot)", X_train[10])

# Start DyNet and define trainer
model = dy.Model()
trainer = dy.SimpleSGDTrainer(model)

num_labels = len(t2i)
print("#labels: {}".format(num_labels))

## as we have a binary classification problem we use 1 output node and binary log loss
num_labels = 1 # binary
loss_function = dy.binary_log_loss

# Q3: define the model parameters
W = None
b = None

# end Q3

# A function to calculate scores for one instance
def calc_score(input_instance):
    dy.renew_cg()
    input_vec = dy.inputVector(input_instance)
    logit = dy.transpose(input_vec) * dy.parameter(W) + dy.parameter(b)
    score = dy.logistic(logit)
    return score[0]


def predict(input_instance):
    """
    predict label for input instance (binary logistic regression)
    :param input_instance:
    :return:
    """
    score = calc_score(instance).npvalue()
    if score > 0.5:
        y_pred = 1
    else:
        y_pred = 0
    return y_pred

EPOCHS=10

# training procedure
for ITER in range(EPOCHS):
      random.shuffle(train)
      train_loss = 0.0
      start = time.time()
      for instance, gold_label in X_train:
          score = calc_score(instance)
          dy_label = dy.scalarInput(gold_label)
          my_loss = loss_function(score, dy_label)
          train_loss += my_loss.value()

          # backprop and update parameters
          my_loss.backward()
          trainer.update()

      print("iter %r: train loss/sent=%.4f, time=%.2fs" % (ITER, train_loss/len(train), time.time()-start))

      # check performance on dev set
      dev_correct = 0.0
      for instance, gold_y in X_dev:
          y_pred = predict(instance)

          if y_pred == gold_y:
              dev_correct += 1
      print("iter %r: dev acc=%.4f" % (ITER, dev_correct/len(X_dev)))


# final testing
test_correct = 0.0
for instance, gold_y in X_test:
    y_pred = predict(instance)
    if y_pred == gold_y:
        test_correct += 1
print("iter %r: test acc=%.4f" % (ITER, test_correct/len(X_test)))