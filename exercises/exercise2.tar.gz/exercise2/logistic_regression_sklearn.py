__author__ = "bplank"
"""
Exercise: sentiment classification with logistic regression in Sklearn

1) Examine the code/data.
   What is the distribution of labels in the data (how many positive/negative)?
   How is a text represented? (Check what the CountVectorizer does)
2) Add code to train and evaluate the classifier. What accuracy do you get? 
3) Implement a simple baseline to compare your system to. Add classification report output.
4) (optional): Add code to output and inspect the predicted instances. 
"""
from collections import Counter
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import numpy as np
import random

def read_file(filename):
    texts, labels = [], []
    for line in open(filename):
        line = line.strip()
        label, text = line.split("||| ")
        label = int(label.strip())
        texts.append(text)
        labels.append(label)
    return texts, labels

def load_and_vectorize():
    """
    loads the data and vectorizes it
    """
    train, y_train = read_file("data/rt-sentiment.train")
    test, y_test = read_file("data/rt-sentiment.test")

    print("vectorize data..")
    vectorizer = CountVectorizer()

    X_train = vectorizer.fit_transform(train) # make sure you understand the difference between fit_transform and transform
    X_test = vectorizer.transform(test)


    print("#train instances: {} #test: {}".format(X_train.shape[0], X_test.shape[0], X_test.shape[0]))
    print("vocab size: {}".format(len(vectorizer.vocabulary_)))
    return X_train, y_train, X_test, y_test


## read input data
print("load data..")
X_train, y_train, X_test, y_test = load_and_vectorize()


### Q2: Train and evaluate the classifier on the dev set -- your code here
clf = LogisticRegression()

print("train model..")
print(clf) # shows which model and its parameters

clf.fit(X_train, y_train)

y_predicted_test = clf.predict(X_test)

## end your code here for Q2

## Q3: Add a simple baseline -- your code here

baseline_test = [1 for _ in y_test]

# random.shuffle(baseline_dev)
## end your code here for Q3



### evaluate
accuracy_test = accuracy_score(y_test, y_predicted_test)

print("===== test set ====")
print("Baseline:   {0:.2f}".format(accuracy_score(y_test, baseline_test)*100))
print("Classifier: {0:.2f}".format(accuracy_test*100))
print("Distribution of labels: {}".format(Counter(y_test)))
