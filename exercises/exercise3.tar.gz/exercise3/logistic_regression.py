__author__ = "bplank"
"""
From a
   Logistic regression classifier in DyNet (with n-hot feature encoding) for multi-class prediction
to a
   Feedforward neural network classifier in DyNet

Q1: The code is a skeleton of a multinomial logistic regression classifier (multi-class prediction). 
    Data for animacy classification is provided (12 classes). Which loss function do we need? 
Q2: Finish the predict function (how does it differ from the binary logistic regression case?) 
    Now you are ready to run the code!
Q3: What performance do you get when running it for 10 epochs? 
Q4: Copy the code and name it 'feedforward_nn.py' - now modify the new code to create a 
    feedforward neural network with one hidden layer (in which places do you need to modify the code?)
    Add a parameter --num-hidden which specifies how many nodes the hidden layer has. 
    Run your code and compare it to the results from the logistic regression model.

"""
from collections import defaultdict
import time
import random
import dynet as dy
import numpy as np
import argparse

parser = argparse.ArgumentParser("Multinomial logistic regression classifier in DyNet")
parser.add_argument('train', help="training file")
parser.add_argument('dev', help="dev file")
parser.add_argument('test', help="test file")
parser.add_argument('--iters', help="epochs (iterations)", type=int, default=10)
args = parser.parse_args()

# mapping functions
w2i = defaultdict(lambda: len(w2i))
t2i = defaultdict(lambda: len(t2i))

UNK = w2i["<unk>"]

def read_data(filename):
    """
    Return a list of tuples (words_in_sentence, label) - both converted to ids
    :param filename:
    :return:
    """
    data = []
    for line in open(filename):
        line = line.strip()
        text, label = line.split("\t")
        word_ids = [w2i[word] for word in text.split()]
        label_enc = t2i[label]
        data.append((word_ids, label_enc))
    return data


def convert_to_n_hot(X, vocab_size):
    """
    Convert instances to n-hot encoding
    :param X:
    :param vocab_size:
    :return:
    """
    out = []
    for word_ids, label in X:
        n_hot = np.zeros(vocab_size)
        for w_idx in word_ids:
            n_hot[w_idx] = 1   # Q1: What happens here?
        out.append((n_hot, label))
    return out


# prepare data
train = read_data(args.train)

w2i = defaultdict(lambda: UNK, w2i) # freeze vocab

dev = read_data(args.dev)
test = read_data(args.test)

# convert instances to n-hot representations
vocab_size = max(w2i.values()) + 1 # OOV

X_train = convert_to_n_hot(train, vocab_size)
X_dev = convert_to_n_hot(dev, vocab_size)
X_test = convert_to_n_hot(test, vocab_size)

## end Q2

print("vocab size: {}".format(vocab_size))

## printing out an example
print("11th instance (as word indices)", train[10])
print("11th instance (n-hot)", X_train[10])

# Start DyNet and define trainer
model = dy.Model()
trainer = dy.SimpleSGDTrainer(model)

num_labels = len(t2i)
print("#labels: {}".format(num_labels))

## Q1: define the appropriate loss function
loss_function = None

# define the model parameters
W = model.add_parameters((num_labels, vocab_size))
b = model.add_parameters(num_labels)


# A function to calculate scores for one instance
def calc_score(input_instance):
    dy.renew_cg()
    input_vec = dy.inputVector(input_instance)
    logit = dy.parameter(W) * input_vec + dy.parameter(b)
    score = dy.logistic(logit)
    return score


def predict(input_instance):
    """
    predict label for input instance (binary logistic regression)
    :param input_instance:
    :return:
    """
    # Q2: implement the predict function

    return y_pred

# training procedure
for ITER in range(args.iters):
      random.shuffle(train)
      train_loss = 0.0
      start = time.time()
      for instance, gold_label in X_train:
          score = calc_score(instance)
          my_loss = loss_function(score, gold_label)
          train_loss += my_loss.value()

          # backprop and update parameters
          my_loss.backward()
          trainer.update()

      print("iter %r: train loss/sent=%.4f, time=%.2fs" % (ITER, train_loss/len(train), time.time()-start))

      # check performance on dev set
      dev_correct = 0.0
      for instance, gold_y in X_dev:
          y_pred = predict(instance)

          if y_pred == gold_y:
              dev_correct += 1
      print("iter %r: dev acc=%.4f" % (ITER, dev_correct/len(X_dev)))


# final testing
test_correct = 0.0
for instance, gold_y in X_test:
    y_pred = predict(instance)
    if y_pred == gold_y:
        test_correct += 1
print("test acc=%.4f" % (test_correct/len(X_test)))
